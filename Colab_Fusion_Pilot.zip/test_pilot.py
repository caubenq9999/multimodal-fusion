import unittest
import numpy as np
from pilot import reciprocal, ranks, metrics, grid_weights, make_model

class TestPilot(unittest.TestCase):
    def test_missing_and_ties(self):
        s=np.array([[[1.,100.],[1.,2.],[0.,1.]]])
        available=np.array([[1,0],[1,1],[1,1]],bool)
        r=reciprocal(s,available,60)
        self.assertEqual(r[0,0,1],0)
        np.testing.assert_allclose(r[0,:,0],[1/61,1/62,1/63])
        np.testing.assert_allclose(r[0,1:,1],[1/61,1/62])

    def test_metrics(self):
        r=ranks(np.array([[3,2,1],[1,3,2]]),np.array([0,2]))
        np.testing.assert_array_equal(r,[1,2])
        self.assertEqual(metrics(r)['MRR'],.75)

    def test_simplex(self):
        w=grid_weights(4)
        self.assertEqual(len(w),286)
        np.testing.assert_allclose(w.sum(1),1,atol=1e-6)
        self.assertTrue((w>=0).all())

    def test_absent_branch_is_miss(self):
        r=ranks(np.full((2,3),-np.inf),np.array([0,2]))
        self.assertTrue(np.isinf(r).all())
        self.assertEqual(metrics(r)['MRR'],0)

    def test_models_and_mask(self):
        try: import torch
        except ImportError: self.skipTest('PyTorch unavailable')
        torch.manual_seed(42)
        q=torch.randn(5,16); v=torch.randn(7,4,16); mask=torch.ones(7,4); mask[:,2]=0
        r=torch.rand(5,7,4)/60; r[:,:,2]=0
        for kind in ['linear','mlp','moe','latent']:
            model=make_model(kind,16,4,8); model.eval()
            pred=model(q,v,mask,r)
            self.assertEqual(tuple(pred.shape),(5,7)); self.assertTrue(torch.isfinite(pred).all())
            other=v.clone(); other[:,2]=torch.randn_like(other[:,2])*100
            torch.testing.assert_close(pred,model(q,other,mask,r))
            pred.square().mean().backward()
            self.assertTrue(any(p.grad is not None and p.grad.abs().sum()>0 for p in model.parameters()))

if __name__=='__main__': unittest.main()
